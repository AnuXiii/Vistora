/** @type {import('tailwindcss').Config} */
export default {
	content: ["./*.html", "./pages/*.html", "./pages/*.js", "./src/*.js"],
	theme: {
		extend: {},
	},
	plugins: [],
};
