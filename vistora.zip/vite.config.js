import { dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import tailwindcss from "@tailwindcss/vite";

const __dirname = dirname(fileURLToPath(import.meta.url));

export default defineConfig({
	plugins: [tailwindcss()],

	base: "/",

	build: {
		rollupOptions: {
			input: {
				main: "/index.html",
				about: "/pages/about.html",
				catalogs: "/pages/catalogs.html",
				education: "/pages/education.html",
			},
		},
	},
});
