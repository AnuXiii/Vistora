export const showAlert = (msg, type) => {
	Toastify({
		text: msg,
		duration: 3000,
		position: "left",
		style: {
			background: type,
			boxShadow: "none",
		},
	}).showToast();
};
